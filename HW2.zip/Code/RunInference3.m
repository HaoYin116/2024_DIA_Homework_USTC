function pred = RunInference3(images, imageModel, pairwiseModel, tripletModel)
% This function performs inference for a Markov network.
%
% Input:
%   images: A struct array of the images for each character in the word.
%   imageModel: The provided image model.
%   pairwiseModel: The provided pairwise factor model.
%   tripletModel: The provided triplet factor model.
%
% Output:
%   pred: An array of predictions for every variable. In particular,
%     pred(i) is the predicted value for images(i).
%

% Your code here:
    %% Task 3
    [num_word, ~] = size(images);    % 子集下有num_word个图像
    pred = zeros(num_word, 1);    % 创建预测，num_word个空集合
    K = imageModel.K;    % K个类别
    p = ones([num_word, K]);    % 概率
    for n = 1:num_word
        for k = 1:K - 1
            p(n, k) = exp(imageModel.W(k, :) * images(n).img(:) + imageModel.bias(k));    % 逻辑回归
        end
        p(n, :) = p(n, :) ./ sum(p(n, :));    % 叠加并取最大值
    end
    [~, pred] = max(p, [], 2);
    
    if num_word < 4
        return
    end
    max_p = zeros([num_word, 1]);
    
    while 1
        for n = 1:num_word
            p1 = zeros([K, 1]);
            for k = 1:K
                pred(n) = k;
                p1(k) = log(p(num_word, pred(num_word))) + log(p(num_word - 1, pred(num_word - 1))) + log(pairwiseModel(pred(num_word - 1), pred(num_word)));
                for w = 1:num_word - 2 %计算单词条件概率
                    p1(k) = p1(k) + log(p(w, pred(w))) + log(pairwiseModel(pred(w), pred(w + 1))) + log(tripletModel(pred(w), pred(w + 1), pred(w + 2)));
                end
            end
            [max_p(n), pred(n)] = max(p1);
        end
        if all(diff(max_p) == 0)
            break
        end
    end
end