function pred = RunInference2_WT(images, imageModel, pairwiseModel, tripletModel)
% This function performs inference for a Markov network.
%
% Input:
%   images: A struct array of the images for each character in the word.
%   imageModel: The provided image model.
%   pairwiseModel: The provided pairwise factor model.
%   tripletModel: The provided triplet factor model.
%
% Output:
%   pred: An array of predictions for every variable. In particular,
%     pred(i) is the predicted value for images(i).
%

% Your code here:
    %% Task 2 WT
    [num_word, ~] = size(images);    % 子集下有num_word个图像
    pred = zeros(num_word, 1);    % 创建预测，num_word个空集合
    K = imageModel.K;    % K个类别
    p = ones([num_word, K]);    % 概率
    for n = 1:num_word
        for k = 1:K - 1
            p(n, k) = exp(imageModel.W(k, :) * images(n).img(:) + imageModel.bias(k));    % 逻辑回归
        end
        p(n, :) = p(n, :) ./ sum(p(n, :));    % 叠加并取最大值
    end
    
    if num_word < 3
        return
    end
    pred_m = zeros([K, num_word]);
 
    for n = 1:K
        pred_m(n, 1) = n;
    end
    p_m = log(p(1,:));

    for n = 2:num_word
        for k_m = 1:K
            p1 = zeros([K,1]);
            for k = 1:K
                p1(k) = log(p(n,k)) + log(pairwiseModel(pred_m(k_m, n - 1), k));
            end
            [P, M] = max(p1);
            p_m(k_m) = p_m(k_m) + P;
            pred_m(k_m, n) = M;
        end
    end
    [~, M] = max(p_m);
    pred = pred_m(M, :);
end