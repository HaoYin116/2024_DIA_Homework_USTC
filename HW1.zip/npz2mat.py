import scipy.io as io
import numpy as np
io.savemat('data.mat', mdict=np.load('./Spherical Hashing/data.npz'))
