""""
作者：印昊
学号：SA23916010
院系：生物医学工程学院（苏州）
邮箱: hao_yin@mail.ustc.edu.cn
"""

import numpy as np
import time
from sklearn.metrics import average_precision_score
from tqdm import *
import matplotlib.pyplot as plt
import cupy as cp
import scipy.io as io

# 加载数据集
data = np.load('./Spherical Hashing/data.npz')
features = data['arr_0']  # 16000x768 的图像数据特征
image_paths = data['arr_2']  # 16000 的图像相对路径
labels = data['arr_1']  # 16000x38 的图像标签

# 分割数据集
query_features = features[:2000]
query_labels = labels[:2000].astype(bool)  # 确保标签是布尔类型
database_features = features[2000:]
database_labels = labels[2000:].astype(bool)  # 确保标签是布尔类型

# 球面哈希函数-训练
# 使用cupy加速运算(cupy->numpy)
def spherical_hashing_train(features, num_bits, max_iter, error_m, error_s):
    features = cp.asarray(features)
    num_samples, num_features = features.shape
    centers = features[cp.random.choice(num_samples, num_bits, replace=False)]
    radii = cp.zeros(num_bits)
    distances = cp.zeros((num_samples, num_bits), dtype=cp.float32)
    hash_codes = cp.zeros((num_samples, num_bits), dtype=cp.int32)
    o_ij = cp.zeros((num_bits, num_bits), dtype=cp.float32)
    f_ij = cp.zeros((num_bits, num_features), dtype=cp.float32)
    f_i = cp.zeros((num_bits, num_features), dtype=cp.float32)
    for iter in tqdm(range(max_iter)):
        for i in range(num_bits):
            # 计算哈希值
            distances[:, i] = cp.linalg.norm(features - centers[i, :], axis=1)
            radii[i] = cp.median(distances[:, i], axis=0)
            hash_codes[:, i] = distances[:, i] <= radii[i]
        # 计算o_ij、f_ij、f_i、更新圆心
        #for i in range(num_bits):
            for j in range(num_bits):
                o_ij[i, j] = cp.sum((hash_codes[:, i] == 1) & (hash_codes[:, j] == 1))
                if i == j:
                    o_ij[i, j] = num_samples / 4
                f_ij[j, :] = 0.5 * (o_ij[i, j] - num_samples / 4) / (num_samples / 4) * (centers[i] - centers[j])
            f_i[i, :] = cp.sum(f_ij, axis=0) / (num_bits - 1)
            centers[i, :] = centers[i, :] + f_i[i, :]
        if cp.average(abs(o_ij - num_samples / 4)) < error_m * num_samples / 4:
            if cp.std(o_ij) < error_s * num_samples / 4:
                break
    mdict_o_ij = {'o_ij': cp.asnumpy(o_ij)}
    io.savemat(f'{num_bits}_o_ij.mat', mdict_o_ij)
    mdict_hash_codes = {'hash_codes': cp.asnumpy(hash_codes)}
    io.savemat(f'{num_bits}_hash_codes.mat', mdict_hash_codes)
    return cp.asnumpy(hash_codes), cp.asnumpy(centers), cp.asnumpy(radii)

# 球面哈希函数-测试
# 使用cupy加速运算(cupy->numpy)
def spherical_hashing_test(features, num_bits, centers, radii):
    features = cp.asarray(features)
    centers = cp.asarray(centers)
    radii = cp.asarray(radii)
    num_samples, num_features = features.shape
    hash_codes = cp.zeros((num_samples, num_bits))
    for i in range(num_bits):
        distances = cp.linalg.norm(features - centers[i], axis=1)
        hash_codes[:, i] = distances <= radii[i]
    return cp.asnumpy(hash_codes)


# 计算Hamming距离
# 距离越短越接近
def hamming_distance(hash_code1, hash_code2):
    return np.sum(hash_code1 != hash_code2, axis=1)

# 评价指标计算
def compute_map_and_curves(query_hashes, database_hashes, query_labels, database_labels, num_bits):
    num_queries = query_hashes.shape[0]
    aps = []
    recalls = []
    precisions = []
    for i in range(num_queries):
        distances = hamming_distance(query_hashes[i], database_hashes)
        sorted_indices = np.argsort(distances)
        sorted_labels = database_labels[sorted_indices]
        relevant = np.sum(query_labels[i] & sorted_labels, axis=1) > 0
        ap = average_precision_score(relevant, -distances)
        aps.append(ap)
        recall = np.cumsum(relevant) / np.sum(relevant)
        precision = np.cumsum(relevant) / np.arange(1, len(relevant) + 1)
        recalls.append(recall)
        precisions.append(precision)
    mean_ap = np.mean(aps)
    mean_recall = np.mean(recalls, axis=0)
    mean_precision = np.mean(precisions, axis=0)
    return mean_ap, mean_recall, mean_precision

# 存储消耗和检索时间
def evaluate_storage_and_time(database_hashes, query_hashes):
    storage_consumption = database_hashes.nbytes
    start_time = time.time()
    for query_hash in query_hashes:
        distances = hamming_distance(query_hash, database_hashes)
    average_retrieval_time = (time.time() - start_time) / len(query_hashes)
    return storage_consumption, average_retrieval_time

# 测试不同比特数的检索性能
bit_lengths = [16, 32, 64, 128]
#bit_lengths = [16]
max_iter = 4000
error_m = 0.01
error_s = 0.01
for num_bits in bit_lengths:
    # 训练球面哈希
    print(f"\nTraining {num_bits}-bit hash codes...")
    database_hashes, centers, radii = spherical_hashing_train(database_features, num_bits, max_iter, error_m, error_s)
    # 保存球面哈希
    mdict_centers = {'centers': centers}
    mdict_radii = {'radii': radii}
    io.savemat(f'{num_bits}_centers.mat', mdict_centers)
    io.savemat(f'{num_bits}_radii.mat', mdict_radii)

    # 测试球面哈希
    print(f"\nEvaluating {num_bits}-bit hash codes...")
    query_hashes = spherical_hashing_test(query_features, num_bits, centers, radii)
    mean_ap, mean_recall, mean_precision = compute_map_and_curves(query_hashes, database_hashes, query_labels,database_labels, num_bits)
    storage_consumption, average_retrieval_time = evaluate_storage_and_time(database_hashes, query_hashes)
    # 保存测试数据
    mdict_recall = {'recall': mean_recall}
    mdict_precision = {'precision': mean_precision}
    io.savemat(f'{num_bits}_recall.mat', mdict_recall)
    io.savemat(f'{num_bits}_precision.mat', mdict_precision)

    # 输出结果
    print(f"mAP: {mean_ap:.4f}")
    print(f"Storage Consumption: {storage_consumption / 1024:.2f} KB")
    print(f"Average Retrieval Time: {average_retrieval_time:.4f} seconds")
    plt.plot(mean_recall, mean_precision, label=f'{num_bits}-bit')
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision-Recall Curve')
    plt.legend()
    plt.savefig(f"{num_bits}bit_Precision")